import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def distance(a, b):
    p, q = map(math.radians, (a[0], b[0]))
    dp = q - p
    dl = math.radians(b[1] - a[1])
    return (
        6371.0088
        * 2
        * math.asin(
            min(
                1,
                math.sqrt(
                    math.sin(dp / 2) ** 2
                    + math.cos(p) * math.cos(q) * math.sin(dl / 2) ** 2
                ),
            )
        )
    )


def build_catalog(site_root=ROOT):
    catalog = site_root / "data/routes.json"
    existing = (
        {r["file"]: r for r in json.loads(catalog.read_text())} if catalog.exists() else {}
    )
    rows = []
    (site_root / "data/details").mkdir(exist_ok=True)
    gpx_dir = site_root / "data/gpx"
    for f in sorted(p for p in gpx_dir.rglob("*") if p.suffix.lower() == ".gpx"):
        relative = f.relative_to(gpx_dir)
        if f.is_symlink():
            raise ValueError(f"Lien symbolique GPX non accepté : {f}")
        if len(relative.parts) > 2 or (len(relative.parts) == 2 and relative.parts[0] not in ("route", "gravel", "vtt")):
            raise ValueError(f"Ranger le GPX dans route, gravel ou vtt : {f}")
        root = ET.parse(f).getroot()
        if root.tag.split("}")[-1] != "gpx":
            raise ValueError(f"Fichier GPX attendu : {f}")
        segments = []
        gain = 0
        km = 0
        missing = False
        profile = []
        for segment_index, seg in enumerate(root.findall(".//{*}trkseg")):
            pts = []
            last = None
            for p in seg.findall("{*}trkpt"):
                ele = p.find("{*}ele")
                e = float(ele.text) if ele is not None else None
                point = [float(p.attrib["lat"]), float(p.attrib["lon"])]
                if not all(math.isfinite(v) for v in point) or not (-90 <= point[0] <= 90 and -180 <= point[1] <= 180):
                    raise ValueError(f"Coordonnées invalides : {f}")
                if e is not None and not math.isfinite(e):
                    raise ValueError(f"Altitude invalide : {f}")
                if pts:
                    km += distance(pts[-1], point)
                if e is None:
                    missing = True
                if e is not None and last is not None:
                    gain += max(0, e - last)
                last = e
                pts.append(point)
                profile.append([round(km, 6), e, *point, segment_index])
            if pts:
                segments.append(pts)
        if sum(map(len, segments)) < 2:
            raise ValueError(f"Pas de trace : {f}")
        route_id = hashlib.sha256(relative.as_posix().encode()).hexdigest()[:12]
        detail_path = site_root / "data/details" / f"{route_id}.json"
        old_detail = json.loads(detail_path.read_text()) if detail_path.exists() else {}
        fingerprint = hashlib.sha256(f.read_bytes()).hexdigest()
        detail = {"points": profile, "fingerprint": fingerprint}
        if old_detail.get("fingerprint") == fingerprint:
            for key in ("surfaces", "surfaceSource", "surfaceDate"):
                if key in old_detail:
                    detail[key] = old_detail[key]
        detail_path.write_text(json.dumps(detail, separators=(",", ":")))
        name = root.find(".//{*}trk/{*}name")
        title = name.text.strip() if name is not None and name.text else f.stem
        # Keep endpoints and enough points for a faithful lightweight preview.
        simplified = [
            p[:: max(1, len(p) // 700)] + ([p[-1]] if len(p) > 1 else []) for p in segments
        ]
        rows.append(
            dict(
                id=route_id,
                detail=f"data/details/{route_id}.json",
                name=title,
                km=round(km, 1),
                gain=None if missing else round(gain),
                sport=relative.parts[0] if len(relative.parts) == 2 else "route",
                direction=None,
                profile=profile[:: max(1, len(profile) // 250)] + [profile[-1]],
                file="data/gpx/" + relative.as_posix(),
                segments=simplified,
            )
        )
    for row in rows:
        old = existing.get(row["file"], {})
        for field in ("name", "sport", "direction"):
            if field in old:
                row[field] = old[field]
    (site_root / "data/routes.json").write_text(
        json.dumps(rows, ensure_ascii=False, separators=(",", ":"))
    )
    print(f"{len(rows)} parcours générés")


if __name__ == "__main__":
    build_catalog()
