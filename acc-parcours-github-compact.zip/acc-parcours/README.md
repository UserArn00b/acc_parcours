# ACC — Les parcours du club

Site statique HTML/CSS/JavaScript prêt pour GitHub Pages. 57 parcours importés : 34 route et 23 gravel. Les orientations sont facultatives et non calculées.

## Aperçu local

Depuis ce dossier :

```sh
python3 tools/prepare_site.py
python3 -m http.server 8000 --directory _site
```

Puis ouvrir http://localhost:8000. Le site doit être servi en HTTP (pas ouvert directement comme un fichier). La préparation recrée entièrement le dossier `_site/` : ne pas le modifier à la main.

## Une seule archive pour les parcours existants

`data/parcours.zip` regroupe les 57 GPX, le catalogue et les profils enrichis. **Garder ce fichier compressé lors de l’envoi sur GitHub.** L’action le décompresse, importe les nouveaux parcours et prépare le site automatiquement. Les fichiers du site et les workflows restent séparés de cette archive.

Seuls les fichiers nécessaires à la consultation sont publiés : l’archive source et les outils restent hors du site. Les GPX proposés au téléchargement restent accessibles aux visiteurs ; ce regroupement ne constitue pas une protection contre la copie.

## Publier sur GitHub Pages

1. Créer un dépôt GitHub nommé par exemple `acc-parcours`, avec une branche principale `main`.
2. Décompresser le paquet `acc-parcours-github-compact.zip`, mais **pas** le fichier `data/parcours.zip` qu’il contient. Envoyer **le contenu** du dossier `acc-parcours` à la racine du dépôt : `index.html`, `app.js`, `style.css`, `data/`, `tools/`, `tests/` et le dossier caché **`.github/`**. Sur Mac, afficher les fichiers cachés avec **⌘ Maj .** pour inclure `.github/`. Ne pas envoyer simplement le paquet ZIP extérieur et ne pas ajouter un niveau de dossier supplémentaire.
3. Dans **Settings → Pages → Build and deployment → Source**, choisir **GitHub Actions**.
4. Dans **Actions → Ajouter les parcours et publier → Run workflow**, sélectionner `main` et lancer la publication. Les prochaines modifications de `main` la déclencheront automatiquement.
5. L’adresse du site apparaît dans **Settings → Pages** et dans le résultat du déploiement.

Sur GitHub Free, utiliser un dépôt public pour GitHub Pages. Le code et les GPX du dépôt sont alors accessibles à tous. Aucun domaine personnalisé ni compte GitHub n’est imposé dans ces fichiers. Le sous-domaine du club pourra être configuré ensuite.

Pour envoyer le dossier avec Git (depuis le dossier décompressé, après création d’un dépôt vide), remplacer `VOTRE_COMPTE` :

```sh
git init -b main
git add .
git commit -m "Catalogue des parcours ACC"
git remote add origin https://github.com/VOTRE_COMPTE/acc-parcours.git
git push -u origin main
```

L’action de publication teste le code, reconstruit le catalogue, puis déploie uniquement les fichiers du site. Les modifications proposées par pull request sont vérifiées sans publication. Aucun jeton personnel n’est nécessaire : les workflows utilisent les permissions intégrées de GitHub.

Les fichiers JSON reconstruits pendant l’action sont publiés, **sans créer de commit automatique** dans le dépôt. La base est `data/parcours.zip` ; les GPX ajoutés dans les sous-dossiers de pratique la complètent. Aucun fichier décompressé du catalogue n’est nécessaire dans le dépôt.

Documentation GitHub : [publication avec Actions](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## Ajouter des parcours depuis GitHub

1. Ouvrir le dossier correspondant à la pratique dans le dépôt :
   - `data/gpx/route/`
   - `data/gpx/gravel/`
   - `data/gpx/vtt/`
2. Choisir **Add file → Upload files**, déposer un ou plusieurs fichiers `.gpx`, puis enregistrer sur `main` (ou proposer une pull request si la branche est protégée).
3. L’action **Ajouter les parcours et publier** calcule distance, dénivelé, miniature et profil, attribue la pratique selon le dossier, lance les tests et publie.
4. Consulter l’onglet **Actions** : un fichier invalide bloque la nouvelle publication, le dernier site publié reste disponible. Corriger le fichier puis relancer.

GitHub Actions ne propose pas de bouton pour joindre un fichier à « Run workflow » : l’envoi se fait d’abord dans le dépôt. Le lancement manuel sert à reconstruire et republier les fichiers déjà déposés.

Conserver les noms et chemins des fichiers existants pour garder leurs liens. Dans l’archive, les anciens GPX restent à la racine de `gpx/`. Les sous-dossiers du dépôt classent les nouveaux parcours. Les sports, noms et directions du catalogue archivé sont conservés. Supprimer un GPX ajouté dans un sous-dossier le retire lors de la prochaine publication ; pour retirer ou corriger un parcours de la base, mettre à jour l’archive elle-même.

Les GPX attendus contiennent des points de trace `trk/trkseg/trkpt` (exports Strava classiques). La direction reste facultative (`null`, N, NE, E, SE, S, SO, O, NO). Les nouveaux parcours n’ont pas de revêtements enrichis tant que l’outil optionnel décrit plus bas n’a pas été lancé.

En local : ajouter les fichiers dans ces mêmes dossiers, lancer `python3 tools/prepare_site.py`, puis vérifier le site servi depuis `_site/` avant l’envoi sur GitHub.

Les cartes détaillées utilisent Leaflet 1.9.4 et les tuiles standard OpenStreetMap avec attribution. Les vignettes chargent un fond OpenStreetMap seulement lorsqu’elles deviennent visibles, avec le tracé et une attribution. Les cartes et les polices distantes nécessitent Internet. La distance est calculée en deux dimensions ; le dénivelé est la somme brute des différences positives d’altitude et peut différer de Strava. Les aperçus sont allégés, les téléchargements GPX restent originaux.

## Profil interactif et revêtements

Le détail charge à la demande `data/details/<id>.json` : tous les points GPX avec distance cumulée, altitude, coordonnées et identifiant de segment. Le survol de la carte ou du profil place le même repère sur les deux vues. Le profil est aussi utilisable avec les flèches du clavier, Début et Fin. Sur une portion commune à l’aller et au retour, le survol de carte privilégie le passage proche du dernier repère ; le profil permet de choisir précisément le passage voulu.

`tools/build_catalog.py` reconstruit ces fichiers et conserve les revêtements uniquement si le GPX n’a pas changé. Une empreinte du fichier empêche d’appliquer les anciens revêtements à une trace modifiée.

Pour enrichir la base en local, commencer par extraire `data/parcours.zip` dans `data/` (les chemins obtenus sont `data/gpx/`, `data/details/` et `data/routes.json`). Ces fichiers de travail sont ignorés par Git. Pour télécharger et importer automatiquement les revêtements : `python3 tools/enrich_surfaces.py --download`. Ce traitement ponctuel peut prendre quelques minutes ; il ne transmet pas les GPX, uniquement leur emprise géographique globale. Il reste hors du site public.

Pour utiliser un extrait déjà téléchargé, récupérer un extrait Overpass JSON contenant les voies `highway`, leurs tags et leur géométrie (`out tags geom;`) sur l’emprise des parcours. Inclure aussi les voies sans tag `surface`, pour éviter d’attribuer le revêtement d’une voie parallèle renseignée à une voie inconnue. Puis lancer :

```sh
python3 tools/enrich_surfaces.py --osm /chemin/vers/extrait-osm.json
python3 -m unittest discover -s tools -p 'test_*.py'
```

Le rapprochement local utilise une distance maximale de 12 m, une direction compatible (à 30° près) et trois échantillons par intervalle d’au plus 30 m. Les correspondances absentes ou ambiguës restent « Non renseigné ». Il s’agit d’une estimation géographique, pas d’une garantie du revêtement ou de la difficulté. Aucune catégorie n’est déduite du sport. Les fichiers enrichis contiennent la date de l’extrait ; les données OpenStreetMap sont attribuées sur le profil (ODbL). La bande présente des catégories regroupées : « Revêtu » inclut notamment asphalte et béton, « Gravier / compacté » regroupe gravel, fine_gravel et compacted.

Après enrichissement, recréer l’archive en conservant sa structure interne (`gpx/`, `details/`, `routes.json` à la racine du ZIP), remplacer `data/parcours.zip`, puis lancer `python3 tools/prepare_site.py` pour vérifier. Envoyer l’archive mise à jour sur GitHub. Ne pas inclure le dossier parent `data/` dans le ZIP. Le site publié ne fait aucune requête Overpass.


## Organisation et vérifications

Aucun framework ni dépendance Python à installer. GitHub Actions prépare automatiquement les données avant de publier le site. `index.html` contient la structure accessible, `style.css` les styles et `app.js` les interactions. Les icônes et couleurs sont centralisées. Les outils Python servent uniquement à préparer les données, hors du navigateur.

Le profil reste complet lors du zoom sur la carte. Les revêtements sont masqués par défaut et activables dans l’aperçu.

Depuis ce dossier, lancer les contrôles sans installer de bibliothèque :

```sh
node --check app.js
node --test tests/app.test.cjs
python3 -m unittest discover -s tools -p 'test_*.py'
```

Les tests couvrent les filtres, le tri, l’interpolation du profil, l’option des revêtements, l’échappement des noms et le rapprochement avec les voies OpenStreetMap.


## Vues du catalogue et non-régression

Les boutons Grille / Liste changent la présentation sans modifier les filtres ni le tri. La liste montre un tracé miniature sans charger de fond de carte supplémentaire. Les lignes ouvrent le même aperçu et le téléchargement reste indépendant. La grille est l’affichage initial à chaque chargement.

La suite comprend 12 tests JavaScript et 12 tests Python. Les tests Python vérifient aussi la préparation depuis l’archive, l’ajout et le retrait de GPX, ainsi que le refus des chemins sortant du dossier prévu. Elle couvre également les changements de vue, la fermeture par clic extérieur (sans fermer après un glissement depuis la carte), le retour du focus, les fonds de carte et les réponses tardives de chargement. Les tests JavaScript utilisent un DOM simulé ; ils ne remplacent pas la vérification visuelle dans un navigateur.

Contrôles navigateur à refaire après une modification de mise en page :

- Filtrer Route et trier par distance décroissante, puis passer de Liste à Grille : mêmes résultats dans le même ordre.
- Ouvrir une ligne, zoomer et déplacer la carte : en-tête et profil restent visibles sans défilement.
- Changer le fond, activer les revêtements et déplacer le repère au clavier.
- Fermer par la croix, Échap et clic extérieur ; un glissement depuis la carte vers l’extérieur ne ferme pas l’aperçu.
- Vérifier les grands chiffres et le téléchargement sur mobile comme sur ordinateur.

La vue Liste utilise un tableau : cliquer sur Distance ou Dénivelé inverse le tri de cette colonne, en synchronisation avec le menu de tri. Les miniatures sont masquées sur mobile pour conserver des colonnes lisibles.


## Nom des fichiers téléchargés

Depuis la grille, la liste ou l’aperçu, le téléchargement propose `route_acc_{DDMMYYYY}_{km}km_{deniv}deniv.gpx`. La date est celle du téléchargement, selon l’heure locale du visiteur. Distance et dénivelé sont arrondis à l’entier le plus proche : `route_acc_18112026_41km_204deniv.gpx`. Le préfixe `route_acc` est commun à toutes les pratiques. Si l’altitude manque dans un GPX, le dénivelé est indiqué par `NA` plutôt qu’un faux zéro.

Seul le nom proposé au téléchargement change : le contenu du GPX et son chemin dans le catalogue restent identiques.

## Accès aux traces

Un GPX proposé au téléchargement peut être copié et redistribué. Chiffrer les fichiers avec une clé livrée au navigateur ne change pas cela. Même sans téléchargement, une carte affichant la géométrie complète permet de récupérer le tracé à partir des données reçues.

Une mention de provenance ACC peut favoriser l’attribution, mais ne bloque pas la copie. Restreindre réellement l’accès demanderait une authentification et un contrôle côté serveur, avec les GPX et les coordonnées détaillées hors des ressources publiques. Même alors, un membre autorisé pourrait partager un téléchargement. Le site livré reste public, conformément au fonctionnement retenu.
